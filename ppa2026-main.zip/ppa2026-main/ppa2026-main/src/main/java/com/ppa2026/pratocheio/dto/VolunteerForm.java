package com.ppa2026.pratocheio.dto;

import lombok.Data;

@Data
public class VolunteerForm {
  private String name;
  private String email;
  private String phone;
  private String availability;
}
