package com.ppa2026.pratocheio.dto;

import lombok.Data;

@Data
public class LoginForm {
  private String name;
  private String password;
}
