package com.ppa2026.pratocheio.dto;

import lombok.Data;

@Data
public class RegistrationForm {
  private String name;
  private String password;
  private String cpf;
  private String phone;
}
