package com.ppa2026.pratocheio.repository;

import com.ppa2026.pratocheio.model.VolunteerApplication;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VolunteerApplicationRepository extends JpaRepository<VolunteerApplication, Long> {}
