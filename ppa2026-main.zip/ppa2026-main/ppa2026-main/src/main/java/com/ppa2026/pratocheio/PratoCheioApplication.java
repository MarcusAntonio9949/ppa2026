package com.ppa2026.pratocheio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PratoCheioApplication {

  public static void main(String[] args) {
    SpringApplication.run(PratoCheioApplication.class, args);
  }
}
